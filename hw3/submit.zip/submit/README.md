## To run the code and get the results from the document, simply run the configurations provided in each experiment from the document. 
## For Colab, simply adjust the parameters according to the command lines in the configurations; otherwise, keep other parameters as default values provided in the jupyter notebook. 
## NOTE!!! For Q1 comparison graph, run the last cell in run_hw3_actor_critic.ipynb.
## NOTE!!! For Q2, add -lr 0.005 or adjust the learning rate to 0.005 in Colab. The number is the same as the experiment in HW2.